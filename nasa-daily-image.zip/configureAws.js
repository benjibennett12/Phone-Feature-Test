const AWS = require('aws-sdk');

AWS.config.update({
  accessKeyId: 'AKIA6GBMDVGG6YNO3A67',
  secretAccessKey: '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',
  region: 'us-east-1',
});

console.log('AWS credentials configured successfully!');
